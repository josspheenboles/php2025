<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
echo '<pre>';
// funcation not case sensitive,
// php support hoisting like js
fun();
function Fun()
{
    echo 'hi';
}
// function test(int $var1,float $var2)
// {
//     echo $var1+$var2;

// }
// test(1,2);
// test('aya','ali');
//function default argumnt
function mysum($val1,$val2=100)
{
    echo $val1+$val2;
}
// mysum(11,2);
// mysum(3);//103
//define type of arguments
function mysum2(int $val1,int $val2=100)
{
    echo $val1+$val2;
}
// mysum2('aya','ali');//Fatal error
//Variable length argument lists
//allow function accpet unlimited number of args ===>(array)
function mysum3(...$arg)
{
    $res=0;
    var_dump($arg);

    foreach ($arg as $val)
    {
        $res+=$val;
    }
    // echo $res;
    //stop function execuation
    return $res;
}
$arr=[1,2,3];
// mysum3(1,2);
mysum3(1,2,3,4);
//Call by value vs Call by reference
function incrementFun($value, $amount = 1) {
$value = $value +$amount;
}
$value=10;
//call by value
incrementFun($value);
var_dump($value); // 10
//call by ref
function incrementFunbyref(&$value, $amount = 1) {
$value = $value +$amount;
}
$value=10;
incrementFunbyref($value);
var_dump($value); // 11
//=====================Closures===============
//function without name aim to group lines of code only 
//its defination must end with ;
//Passing a Closure as a Callback array_map

$varclousr=function (){echo '<h1>hi iam closures function</h1>';};
// var_dump(is_callable($varclousr));
$varclousr2=function ($var1,$val2=100)
{
    echo "<h1>hi iam closures function {$var1} ===> {$val2}</h1>";
};
// var_dump($varclousr2);
// $varclousr2('aya');
//==========Closures and external variables.===============
$num=90;
$clos=function ($var) use($num)
{
    //accsess $num 
    //cant modified it
    var_dump($num);
    //define new local var in function scope called $num
    $num=80;
    exit();
};
var_dump($clos);
$clos('jj');
var_dump($num);
echo '</pre>';

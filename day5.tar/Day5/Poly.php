<?php
//Overloading.
//Overriding.
// =======Dynamic binding
Interface Animals{
public function makeNoise();
}
class Cat implements Animals{
public function makeNoise(){
$this->meow();
}
function meow(){
echo '<br> mewo';
}
}
class Dog implements Animals{
public function makeNoise(){
$this->bark();
}
function bark(){
echo '<br> bark';
}
}
//====
Interface Animals{
public function makeNoise();
}
class Cat implements Animals{
public function makeNoise(){
$this->meow();
}
function meow(){
echo '<br> mewo';
}
}
class Dog implements Animals{
public function makeNoise(){
$this->bark();
}
function bark(){
echo '<br> bark';
}
}


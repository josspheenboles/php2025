<?php
//=====Bind a closure to a class
//Closure can access public properties only
$myclousre=function()
    {
        
    echo $this->property."<br>";
    };
class MyClass
{
    public $property;
    function __construct($propertyValue)
    {
        $this->property=$propertyValue;
    }
}

$objClass= new MyClass("Hello from clousre");
// $myclousre($objClass);
$myBoundClousre= $myclousre->bindTo($objClass);
var_dump($myBoundClousre);
$myBoundClousre();

// //==============access the private members inside a class using the closure
$myclousre=function()
    {
        echo $this->property."<br>";
    };
class MyClass
{
    private $property;
    function __construct($propertyValue)
    {
        $this->property=$propertyValue;
    }
}

$objClass= new MyClass("Hello from clousre");
$myBoundClousre= $myclousre->bindTo($objClass,MyClass::class);
// //MyClass::Class -> class constant reference , bindto takes the scope
// $myBoundClousre();

//==============Bind a closure to a class
$myclousre=function()
    {
        echo $this->property."<br>";
    };
class MyClass
{
    private $property;
    function __construct($propertyValue)
    {
        $this->property=$propertyValue;
    }
}
$objClass= new MyClass("Hello from clousre using call");
$myclousre->call($objClass);

//===========Deﬁne a closure inside a class
class NewClass
{
    private $prop;
    function __construct($propertyValue)
    {
        $this->prop=$propertyValue;
       
    }
    function display()
    {
      // // a clousure here....
        // return function()
        // {
        //     echo $this->prop."<br>";
        // };   
        // // a clousure here....
        return function()
        {
            echo $this->prop."<br>";
        };
    }
}
$obj= new NewClass("Hello World");
$display= $obj->display();
$display(); // Hello world
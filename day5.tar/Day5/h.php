 <?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// $arr=[1,2,3];
$arr=[];
function test($len)
{
    
    for ($i=0;$i<$len;$i++)
    {
        yield $i;
    }

}
$arr=test(3);
// class Human
// {
//     public $id;
//     public $name;
//     function __construct($id,$name)
//     {
//         $this->id=$id;
//         $this->name=$name;
      
//     }
//       function display()
//     {
//         echo "<h1>{$this->id} \n {$this->name}</h1>";
//     }
// }
// function test($obj)
// {
//     $obj->id=3;
//     var_dump($obj);
// }
// $aya=new Human(1,'aya');
// test($aya);
// // $obj2=clone $aya;
// // $obj2->id=1000;
// // $obj2->display();
// $aya->display();

// function test(Animal $x)
// {

// }
// test($objcat);
//  class Human
// {
       
//     static $count=0;
//     public $id;
//     public $name;
//     function __construct($id,$name)
//     {
//         $this->id=$id;
//         $this->name=$name;
//         Human::$count+=1;
//     }
//       function display()
//     {
//         echo "<h1>{$this->id} \n {$this->name}</h1>";
//     }
//     function __toString()
//     {
//         return "<h1>iam {$this->name}</h1>";
//     }
//     static function getpoulation()
//     {
//         echo "<h1>{Human::$count}</h1>";
//     }
//      function walk();
    
// }
// class Employee extends Human
// {
//     static $count=0;
//     public $salary;
//     function __construct($id,$name,$salary)
//     {
//        parent::__construct($id,$name);
//        self::$count+=1;
//        $this->salary=$salary;
//     }
//     function display()
//     {
//         return "<h1>iam {$this->name} my salary:{$this->salary}</h1>";
//     }
//     function __toString()
//     {
//         return "<h1>iam {$this->name} my salary:{$this->salary}</h1>";
//     }
    
// }
// $obj1=new Human(1,'aya ali');
// var_dump($obj1);

// $emp=new Employee(2,'mark ali',3000);
// echo $emp->display();
// print($emp);
// echo $obj1;
// Human::getpopulation();
// // var_dump($emp);
// // echo Employee::$count;
// // echo Human::$count;
// // $obj1=new class(1,1,'sd',4000)
// // {
// //     const pi=3.14;
// //     static $count;
// //     public $id;
// //     private $salary;
// //     protected $age;
// //     public $name;
// //     //constructor
// //     function __construct($id,$age,$name,$salary=3000)
// //     {
// //         $this->id=$id;
// //         $this->name=$name;
// //         echo '<h1>iam const</h1>';
// //     }    
 
// // };
// // var_dump($obj1);
// // // class Human
// // // {
// // //     //properity
// // //     const pi=3.14;
// // //     static $count;
// // //     public $id;
// // //     private $salary;
// // //     protected $age;
// // //     public $name;
// // //     //constructor
// // //     function __construct($id,$age,$name,$salary=3000)
// // //     {
// // //         $this->id=$id;
// // //         $this->name=$name;
// // //         $this->setsalary($salary);
// // //         // $this->salary=$salary;
// // //         $this->age=$age;
// // //         Human::$count+=1;
// // //         // self::$count+=1;
// // //         var_dump(self::$count);
// // //         echo '<h1>iam const</h1>';
// // //     }
// // //     function setsalary($newsalary)
// // //     {
// //         if($newsalary >=3000 && $newsalary<=5000)
// //         {
// //             $this->salary=$newsalary;
// //         }
// //         else
// //         $this->salary=3000;
// //     }
// //     function getsalary()
// //     {return $this->salary;}
// //     private function display()
// //     {echo '<h1>diaplay</h1>';}

// //     // function __set($propname,$value)
// //     // {
// //     //     if($propname=='salary')
// //     //     {
// //     //         if($value >=3000 && $value<=5000)
// //     //             {
// //     //                 $this->$propname=$value;
// //     //             }
// //     //             else
// //     //                 $this->$propname=3000;
// //     //     }        

// //     // }
// //     // function __get($propname)
//     // {
//     //     return $this->$propname;
//     // }
//     function __destruct()
//     {
//         Human::$count-=1;
//         echo "<h1>iam destruct {$this->name}</h1>";
//     }

// }
// $obj1=new Human(1,23,'aya ali',5000);
// // $obj2=new Human(1,23,'mark ali');
// $obj1->intake='asd@gmail.com';
// // $obj1->__set('salary',100000);
// // $obj1->__set('name','abdo');
// var_dump($obj1->intake);
// var_dump($obj1);
// // var_dump(Human::$count);    
// // unset($obj1);
// // var_dump(Human::$count);    
// // var_dump(Human::pi);
// // var_dump($obj2);
// // $obj1=new Human();
// // $obj1->id=100;
// // echo $obj1->id;
// // $obj2=new Human;
// // var_dump($obj1);
// // // $name='aya ali';
// // // $var=function (int $v1,$v2=10)  use($name)
// // // {
// // //     // global $name;
// //     //create local var name ='asd'
// //     $name='asd';
// // echo "<pre>{$name}</pre>";
// // };
// // var_dump($var);
// // $var(100,'aya');
// // echo "<pre>{$name}</pre>";
// // // $var=1;
// // // var_dump($var);
// // // if(is_callable($var))
// // // {
// // //     $var();
// // // }

// // function test(&$arg)
// // {
// //     $arg='ali';
// //     echo '<pre>';
// //     var_dump($arg);#ali
// //     echo '</pre>';
// // }
// // // $var='aya';
// // test($var);
// // var_dump($var);
// // // $arr=['aya'];
// // // test(...[1,'aya',[]]);
// // // test('aya');
// // // test($arr); -->
<?php
//+==========Inheritance
//no multiple Inheritance
//overriding
class Person
{
    public $name;
    public function __construct()
    {
        echo "creating a person ";
    }
    public function callingPerson()
    {
        echo "I am a person";
    }
    public function say_hello()
    {
        echo "Hello person";
    }
}
class Studnet extends Person
{
    public $level;
    public function __construct()
    {
        parent::__construct();
        echo "creating a student";
    }
    public function callingStudent()
    {
        echo "I am a person";
    }
    //overriding
    public function say_hello()
    {
        echo "Hello Student";
    }
}
$std= new Studnet();
$std->name="Omar";
$std->level=1;
$std->callingPerson();
$std->callingStudent();

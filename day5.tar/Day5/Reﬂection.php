<?php
/*
reﬂection is asking an object to tell
you about its properties and methods,
and altering those members
*/
class Human 
{
    private $id;
    protected $name;
    public $gender;
    const PI = 3.1415;
    static $count=0;
    public function __construct() 
    {
        $this->name = "aya";
        $this->gender = "F";
        $this->id=90;
    }
    public function getname() 
    {
        return $this->name;
    }
    private function test(){}
}

$reflection_class = new ReflectionClass("ReflectionClass");
// var_dump($reflection_class->getMethods());
echo '<pre>';
// foreach ($reflection_class->getMethods() as $method) 
// {
//     echo $method->getName() . "<br>";
// }
foreach ($reflection_class->getproperties() as $property) 
{
    echo $property->getName() . "<br>";
}
echo '</pre>';
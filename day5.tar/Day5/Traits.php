<?php
trait Hello 
{
    public $pi=3.14;
    public function sayHello() 
    {
    echo ' <br> Hello ';

    }

    public function sayomr() 
    {
    echo ' <br> Hello omr';

    }

    
}
trait World 
{
    public function sayWorld() 
    {
    echo 'World';
    }
}
class MyHelloWorld 
{
use Hello, World;
public function sayExclamationMark() {
echo '!';
}
}
$o = new MyHelloWorld();
$o->sayHello();
$o->sayomr();
$o->sayWorld();
echo $o->pi;
$o->sayExclamationMark();class MyHelloWorld {
use Hello, World;
public function sayExclamationMark() {
echo '!';
}
}
$o = new MyHelloWorld();
$o->sayHello();
$o->sayWorld();
$o->sayExclamationMark();
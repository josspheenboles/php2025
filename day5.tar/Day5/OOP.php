<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
echo '<pre>';
//=============Encapsulation
//=============Inheritance:
//=============Polymorphism:
//=============Abstraction:
//=============Reﬂection:allows inspection of classes, interfaces, ﬁelds and
// methods at runtime
//define class
class Human
{
    //properties
    const type='Human';
    static $count=0;
    public $name;//accsess from any where
    protected $gender;//accsess from class & child
    private $id;//accsess in the class only
    //constructor
    function __construct($id=0,$name='',$gender='M')
    {
        $this->name=$name;
        $this->id=$id;
        $this->gender=$gender;
        Human::$count+=1;
        echo "<h1>hi iam constr.</h1>";
    }
    function __destruct(){
           echo "<h1>hi iam destr. for {$this->name}</h1>";
    }
    //methods
    //$this--->object && $self--->classs
    public function display()
    {
        echo "<h1>$this->name  ,$this->id</h1>";
    }
    //====setter & getter
    function setid($NEWID)
    {
        $this->id=$NEWID;
    }
    function getid()
    {
        return $this->id;
    }
    //====daynamic setter & getter
    function __set($propertyname,$value)
    {
        echo "<h1>{$propertyname}  set</h1>";
        $this->$propertyname=$value;
    }
    function __get($propertyname)
    {
        echo "<h1>{$propertyname}  get</h1>";
        return $this->$propertyname;
    }
    //static method
    static function getpopulation()
    {
        return Human::$count;
    }

}
//create object
$obj1=new Human(90,'aya','F'); //or $obj1=new Human; if has default constructor
$obj1->__set('id',8080);
echo "<h1>{$obj1->__get('id')}</h1>";
// Human::$count+=1;
// var_dump(Human::$count);
// var_dump(Human::type);
// $obj1->name='aya ali';
// $obj1->setid(70);
// $obj1->id=9;//Fatal error
// $obj1->gender='F';//Fatal error
//====deprecated Creation of dynamic property 
//add proprty to object used with json,stdclass
// $obj1->email='asd@gmail.com';
$obj2=new Human(80,'mark','M'); 
// unset($obj1);
// $obj2->name='mark';
// $obj2->setid(90);
// // var_dump($obj1);
// var_dump($obj2);
$obj1->display();
$obj2->display();
echo Human::$count;
echo Human::getpopulation();

echo '</pre>';

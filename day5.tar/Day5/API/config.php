<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'mydatabase');
define('DB_USER', 'root');
define('DB_PASS', '');

// Define API response format
header("Content-Type: application/json; charset=UTF-8");
?>

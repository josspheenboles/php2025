<?php
//Using cURL (Recommended)
$url = "https://jsonplaceholder.typicode.com/posts/1"; // API URL

$ch = curl_init(); // Initialize cURL
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
print_r($data);

//Using file_get_contents() (Simpler, but Limited)

$url = "https://jsonplaceholder.typicode.com/posts/1"; // API URL

$response = file_get_contents($url);
$data = json_decode($response, true);

print_r($data);
?>
<!-- //Calling an API with POST Data -->
 <?php
$url = "https://jsonplaceholder.typicode.com/posts"; // API URL

$data = [
    'title' => 'New Post',
    'body' => 'This is a test post.',
    'userId' => 1
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>
<!-- Calling an API with Authentication (Bearer Token) -->
 <?php
$url = "https://api.example.com/protected-data";
$token = "your_token_here";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $token",
    "Content-Type: application/json"
]);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>
<!-- Calling an API with DELETE Method -->
 <?php
$url = "https://jsonplaceholder.typicode.com/posts/1"; // API URL

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>


<?php
require_once 'database.php';

$db = new Database();
$conn = $db->getConnection();

$requestMethod = $_SERVER["REQUEST_METHOD"];
$input = json_decode(file_get_contents("php://input"), true);

switch ($requestMethod) {
    case "GET":
        getRecords($conn);
        break;
    case "POST":
        addRecord($conn, $input);
        break;
    case "PUT":
        updateRecord($conn, $input);
        break;
    case "DELETE":
        deleteRecord($conn, $input);
        break;
    default:
        echo json_encode(["error" => "Invalid request method"]);
}

function getRecords($conn) {
    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

function addRecord($conn, $input) {
    if (!isset($input['name']) || !isset($input['email'])) {
        echo json_encode(["error" => "Missing fields"]);
        return;
    }

    $stmt = $conn->prepare("INSERT INTO users (name, email) VALUES (:name, :email)");
    $stmt->bindParam(":name", $input['name']);
    $stmt->bindParam(":email", $input['email']);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Record added"]);
    } else {
        echo json_encode(["error" => "Failed to add record"]);
    }
}

function updateRecord($conn, $input) {
    if (!isset($input['id']) || !isset($input['name']) || !isset($input['email'])) {
        echo json_encode(["error" => "Missing fields"]);
        return;
    }

    $stmt = $conn->prepare("UPDATE users SET name=:name, email=:email WHERE id=:id");
    $stmt->bindParam(":id", $input['id']);
    $stmt->bindParam(":name", $input['name']);
    $stmt->bindParam(":email", $input['email']);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Record updated"]);
    } else {
        echo json_encode(["error" => "Failed to update record"]);
    }
}

function deleteRecord($conn, $input) {
    if (!isset($input['id'])) {
        echo json_encode(["error" => "Missing ID"]);
        return;
    }

    $stmt = $conn->prepare("DELETE FROM users WHERE id=:id");
    $stmt->bindParam(":id", $input['id']);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Record deleted"]);
    } else {
        echo json_encode(["error" => "Failed to delete record"]);
    }
}
?>

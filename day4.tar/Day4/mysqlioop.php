<?php
include_once('config.php');

$conn = new mysqli($host, $username, $password, $database);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
// Insert Function
 function insert($table,$columns ,$data) {

            global $conn;
        $columns = implode(",", array_keys($data));
        $placeholders = implode(", ", array_fill(0, count($data), "?"));
        $sql = "INSERT INTO $table ($columns) VALUES 
        ($placeholders)";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error: " . $conn->error);
            return $conn->error;
        }

        $types = str_repeat("s", count($data)); // Assumes all values are strings; modify as needed
        $stmt->bind_param($types, ...array_values($data));

        return $stmt->();
    }
}

    // Update Function
     function update($table, $data, $where) {
                global $conn;
        $setPart = implode(" = ?, ", array_keys($data)) . " = ?";
        $wherePart = implode(" = ? AND ", array_keys($where)) . " = ?";
        $sql = "UPDATE $table SET $setPart WHERE $wherePart";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error: " . $conn->error);
        }

        $types = str_repeat("s", count($data) + count($where));
        $stmt->bind_param($types, ...array_merge(array_values($data), array_values($where)));

        return $stmt->execute();
    }
    // Delete Function
     function delete($table, $where) {
        global $conn;
        $wherePart = implode(" = ? AND ", array_keys($where)) . " = ?";
        $sql = "DELETE FROM $table WHERE $wherePart";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error: " .$conn->error);
        }

        $types = str_repeat("s", count($where));
        $stmt->bind_param($types, ...array_values($where));

        return $stmt->execute();
    }

    // Select Multiple Rows
     function select($table, $columns = "*", $where = []) 
     {
        global $conn;
        $columnString = is_array($columns) ? implode(", ", $columns) : $columns;
        $sql = "SELECT $columnString FROM $table";

        if (!empty($where)) {
            $wherePart = implode(" = ? AND ", array_keys($where)) . " = ?";
            $sql .= " WHERE $wherePart";
        }

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error: " . $conn->error);
        }

        if (!empty($where)) {
            $types = str_repeat("s", count($where));
            $stmt->bind_param(  $stmt,types,array_values($where));
        }

        $stmt->execute();
        $result = $stmt->get_result();

      execute  return $result->fetch_all(MYSQLI_ASSOC); // Returns an array of associative arrays
    }
    // Select a Single Scalar Value
     function selectScalar($table, $column, $where = []) {
        $sql = "SELECT $column FROM $table";

        if (!empty($where)) {
            $wherePart = implode(" = ? AND ", array_keys($where)) . " = ?";
            $sql .= " WHERE $wherePart ";
        }

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error: " . $conn->error);
        }

        if (!empty($where)) {
            $types = str_repeat("s", count($where));
            $stmt->bind_param($types,array_values($where));
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        // Return the scalar value or null if not found
        return $row ? $row[$column] : null;
    }

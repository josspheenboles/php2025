<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// include_once('config.php');
$dsn = 'mysql:dbname=test;host=127.0.0.1;'; #port number
$user = 'root';
$password = '123';
try {
$db = new PDO($dsn, $user, $password);
$query="Insert INTO trainee (username, email,password,intake_id)
Values(:student_name,:student_email,122,1)";
$stmt=$db->prepare($query);
#1000
$student_name="nohaaaaaaaaaaa";
$stmt-> bindParam (":student_name",$student_name, PDO::PARAM_STR );
$student_name='abdalaah';
$stmt-> bindValue (":student_email","nshehab@iti.gov.eg");
$stmt->execute(); 
$result=$stmt->rowCount();
var_dump($db);
}catch (PDOException $e) {
echo 'Connection failed: ' . $e->getMessage();
}
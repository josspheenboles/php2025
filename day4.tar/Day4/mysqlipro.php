<?php
include_once('config.php');
//insert,update,delete
function dmloperation($sql)
{
     global $host,$username,$password,$database;
    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // Execute the query
    if (mysqli_query($conn, $sql)) 
    {
        return TRUE;
        // return mysqli_insert_id($conn);
    } 
    else 
    {
        return "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    // Close the connection
    mysqli_close($conn);

}
//select return row or rows
function SelectOperation($sql)
{
    global $host,$username,$password,$database;
    
    // Create a connection to the database
    $conn = mysqli_connect($host, $username, $password, $database);

    // Check the connection
    if (!$conn) {
        return "Connection failed: " . mysqli_connect_error();
    }
    // Execute the query
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful
    if (!$result) {
        return "Error: " . mysqli_error($conn);
    }

    // Fetch the data as an associative array
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    // Free the result set
    mysqli_free_result($result);

    // Close the connection
    mysqli_close($conn);

    return $rows;
}
//return single value
function selectscalar($sql)
{
 global $host,$username,$password,$database;
// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare the statement
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    die("Error preparing statement: " . mysqli_error($conn));
}


// Execute the statement
if (!mysqli_stmt_execute($stmt)) {
    die("Error executing statement: " . mysqli_stmt_error($stmt));
}

// Bind the result
mysqli_stmt_bind_result($stmt, $email);

// Fetch the scalar value
if (mysqli_stmt_fetch($stmt)) {
    echo "Email of trainee with ID $traineeId: " . $email;
} else {
    echo "No trainee found with ID $traineeId.";
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
}

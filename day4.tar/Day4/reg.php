<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
    include_once('templats/header.php');
    include_once('blogic.php');          
      echo '<pre>';
    //   print_r(getallintakes());    
      echo '</pre>';
?>
<td colspan=10>
<form action="saveregdata.php" method="post" enctype="multipart/form-data">
        <!-- <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br> -->

        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="image">Upload Image:</label><br>
        <input type="file" id="image" name="image" accept="image/*" required><br><br>
        <select name=intake >
            
            <?php
            
             foreach (getallintakes() as $intake)
             {
                echo "<option value=".$intake['id'].">".$x['name']."</option>";
                
             }
            ?>
            
        </select>

        <input type="submit" value="Register">
    </form>
</td>
<?php
    include_once('templats/footer.php');
?>
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

var_dump($_FILES['image']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate inputs
    $errors = [];
// var_dump($_POST);
    
    // Validate Username
    if (empty($_POST['username'])) {
        $errors[] = "Username is required.";
    } else {
        $username = htmlspecialchars(trim($_POST['username']));
        if (!preg_match("/^[a-zA-Z0-9_]{5,20}$/", $username)) {
            $errors[] = "Username must be 5-20 characters long and can only contain letters, numbers, and underscores.";
        }
    }

    // Validate Password
    if (empty($_POST['password'])) {
        $errors[] = "Password is required.";
    } else {
        $password = trim($_POST['password']);
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        } elseif (!preg_match("/[A-Z]/", $password) || !preg_match("/[a-z]/", $password) || !preg_match("/[0-9]/", $password)) {
            $errors[] = "Password must contain at least one uppercase letter, one lowercase letter, and one number.";
        }
    }

    // Validate Email
    if (empty($_POST['email'])) {
        $errors[] = "Email is required.";
    } else {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        }
    }

    // Validate Image Upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['image']['name']);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file is an image
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check === false) {
            $errors[] = "File is not an image.";
        }

        // Check file size (5MB max)
        if ($_FILES['image']['size'] > 5000000) {
            $errors[] = "File is too large. Maximum size allowed is 5MB.";
        }

        // Allow only certain file formats
        $allowed_types = ['jpg', 'jpeg', 'png'];
        if (!in_array($imageFileType, $allowed_types)) {
            $errors[] = "Only JPG, JPEG and PNG files are allowed.";
        }
    } else {
        $errors[] = "No image file uploaded.";
    }

    // If no errors, proceed with database insertion
    if (empty($errors)) {
        // Hash the password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Move uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            include_once('blogic.php');
            $res=inserttrainee($_POST['username'],$_POST['password'],
            $_POST['email'],$_POST['intake'],$target_file);
            echo $res;
        } else {
            $errors[] = "Sorry, there was an error uploading your file.";
        }
    } else {
        // Display errors
        foreach ($errors as $error) {
            echo "<p style='color: red;'>$error</p>";
        }
    }
}
?>
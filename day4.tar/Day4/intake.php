<?php
include_once('blogic.php');
$intakes=(getallintakes());#0 rows

echo '<select name=intake>';
foreach (getallintakes()  as $intake)
{
    // echo "<option value={$intake['id']}> {$intake['name']}</option>";
}
echo'</select>';
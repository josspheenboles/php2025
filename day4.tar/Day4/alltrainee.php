<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include_once('blogic.php');
var_dump(getalltrainees());
echo '<table border=1>
<tr>
    <th>ID</th>
    <th>User Name</th>
    <th>Email</th>
    <th>Intake</th>
    <th>Profile pic</th>
    <th>Actions</th>
</tr>';

foreach (getalltrainees() as $trainee)
{
    echo "<tr>
   <td>{$trainee['id']}</td>
    <td>{$trainee['username']}</td>
    <td>{$trainee['email']}</td>
    <td>{$trainee['intake_id']}</td> #
    <td>    
    <img src='{$trainee['profile_image']}' width=20% height=20%/>
    </td>
    <td>
        <a href='updatetrainee.php?id={$trainee['id']}'>Update</a>
        <a href='deletetrainee.php?id={$trainee['id']}'>delete</a>
    </td>

    </tr>";
}
echo '</table>';
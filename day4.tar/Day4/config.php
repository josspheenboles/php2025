<?php
// Database connection details
$host = 'localhost'; // or your host
$username = 'root'; // your database username
$password = '123'; // your database password
$database = 'test'; // your database name

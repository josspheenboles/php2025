<?php
include_once('mysqlipro.php');
insertmysqlipro();
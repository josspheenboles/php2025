<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// include_once('mysqlipro.php');
// include_once('mysqlioop.php');
include_once('PDOFUN.php');

function getallintakes()
{
    //mysqli proced.
        // $sql='select * from intake ';
        // $res=SelectOperation($sql);
        // return $res;
    //mysqli oop
        // $res=select('intake','*');    
        // return $res;
    // //pdo
    $res=mySelect('intake');
    return $res;


}
function getalltrainees()
{   //pdo
    $res=mySelect('trainee');
    return $res;
}
// function trainevalis($email)
// {
    
// }
function inserttrainee($age,$username,$password,$email,$intake_id,$image)
{
  
    //mysqli proc
    $sql="insert into trainee (username,password,email,intake_id,profile_image)
    values({$username},{$password},{$email},{$intake_id},?{$image})";
     if(dmloperation($sql))
     {
        return '<div><h1>Trainee added</h1></div>';
     }
     else
    {
        return '<div><h1>Error while Trainee adding </h1></div>';
    }
    // //PDO
    // $res=myinsert('trainee',['email','username','password','intake_id','profile_image'],
    // [$email,$username,$password,$intake_id,$image]);
    // if($res>0)
    // {return '<div><h1>Trainee added</h1></div>';}
    // else
    // {return '<div><h1>Error while Trainee adding </h1></div>';}
}


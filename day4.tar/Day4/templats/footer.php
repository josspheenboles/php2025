
    <tr>
        <td colspan=10 align=center> 
            <h1>copy erights @Intake 45</h1>
        </td>
    </tr>
</table>

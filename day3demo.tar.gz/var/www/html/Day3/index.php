<table border=1 width=100% height=100%>
    <tr>
        <td colspan=10 align=center> 
            <h1>Intake 45</h1>
        </td>
    </tr>
    <tr> 
      <td colspan=3></td>
      <td colspan=7>
        <?php 
        emptyblock('content') ;
        ?>
        <?php
        endblock();
        ?>

      </td>
</tr>

    <tr>
        <td colspan=10 align=center> 
            <h1>copy erights @Intake 45</h1>
        </td>
    </tr>
</table>

<form method=post>
    <input type=text name=str>
    <input type=submit name=bt value='send'>

</form>
<?php
// $email_validation_regex = '/^\\S+@\\S+\\.\\S+$/'; 
// $email='asd@ff.cc';
// if(preg_match($email_validation_regex,$email)===1)
// {echo 'mateched';}
// filiter_var($string,FILTER_VALIDATE_BOOLEAN);
// $var1='Aya ali sayed';
// $var2='aya';
// var_dump(md5($var1));
// var_dump(str_repeat($var1,2));
// var_dump(stripos($var1,$var2));
// var_dump(strcasecmp($var1,$var2));
// var_dump(strlen($var1));
// if(strcmp($var1,$var2)==0)
// {echo 'identical';}
// else
// {echo 'not identical';}
// $msg='aya ali ahmed';
// $token = strtok($msg, " ");
// echo $token."<br />";
// while ($token != "") {
// // $token = strtok("");
// echo $token."<br />";}
// // if(isset($_POST['bt']))
// // {
//     var_dump(explode(' ',$_POST['str'],2));
//     // $sqlquery="select * from trainee where name ='".addslashes($_POST['str'])."'";
//     // $newcontent=addslashes($_POST['str']);
//     // print(stripslashes($newcontent));
//     // // var_dump($sqlquery);
// }
// $msg="hi %s 
// welcome %s";
// // echo $msg;
// print($msg);
// print(sprintf($msg,'ahmed ali','intake 45'))    ;
// print($var);
// print(ucfirst($msg));
// echo '<br>';
// print(ucwords($msg));
// // $content='aya ali
// // mai ahmed';
// // echo nl2br($content);
// $name='  aya ali  ';
// print("<h1>$name</h1>");

// var_dump($name);
// var_dump(ltrim($name));
// // chop==rtrim
// var_dump(chop($name));


?>
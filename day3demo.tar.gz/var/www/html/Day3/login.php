<?php
//start session
session_start();
include_once('templats/header.php')
?>
   <td colspan=10>
<form  method=post>

<label>User Name:</label>
<input type=text name='UserName' required>
</br>

<label>Password:</label>
<input type=password name='Password' required>


<input type=submit value='Login' name=Login>
</br>
<input type=checkbox name='remember'><label>Remember Me</label>

</form>
      
   </td>  
<?php
include_once('templats/footer.php');
$values=['ali','123'];

if(isset($_POST['Login']))
{
    //check username&password
    if($_POST['UserName']==$values[0] 
    and $_POST['Password']==$values[1] )
    {
     //set username
     $_SESSION['usernmae']   =$_POST['UserName'];
     //redirect
     header('location:http://localhost/Day3/Home.php');
    }
    else
    {
        echo '<div> <h1>invalid username and password</h1></div>';
    }
}
?>


    <td colspan=3>
        <a href='list.php'>List</a>
        </br>
        <a href='search.php'>search</a>
        </br>
        <a href='Logout.php'>Logout</a>
        </br>
        
    </td>

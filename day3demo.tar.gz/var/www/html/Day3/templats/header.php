<table border=1 width=100% height=100%>
    <tr>
        <td colspan=10 align=center> 
            <h1>Intake 45</h1>
            <?php
      session_start();
      ?>
      <h1>welcome <?php echo $_SESSION['usernmae'];?> content2</h1>
        </td>
    </tr>
    <tr> 
      
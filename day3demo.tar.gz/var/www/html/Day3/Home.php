<?php
//start session
session_start();
include_once('templats/header.php');
include_once('templats/menu.php');
?>
<td colspan=7>
<?php
echo '<h1>content</h1>';
?>
<h1>welcome <?php echo $_SESSION['usernmae'];?> content2</h1>
</td>
</tr>
<?php
include_once('templats/footer.php');
?>
<?php
session_start();
//remove username session
unset($_SESSION['usernmae']);
//remove all sessions
session_destroy();
// $_SESSION=array();